JUEGO AHORCADO CON JS
bibliografia:
https://www.youtube.com/watch?v=0kR_DuUuX0A
https://developer.mozilla.org/es/docs/Web/API/Fetch_API/Using_Fetch
https://developer.mozilla.org/es/docs/Web/API/Blob
https://somospnt.com/blog/217-agustin-luna